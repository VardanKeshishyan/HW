#include <gtest/gtest.h>
#include "timer.h"
#include "avltree.h"
#include "bst.h"
#include "bstree.h"
#include <gtest/gtest.h>

TEST(BSTreeTest, InsertFind) {
    BSTree bst;
    bst.insert("MyName");
    bst.insert("randName");
    bst.insert("Vardan");
    bst.insert("Keshishyan");
    EXPECT_TRUE(bst.find("MyName"));
    EXPECT_TRUE(bst.find("randName"));
    EXPECT_TRUE(bst.find("Vardan"));
    EXPECT_TRUE(bst.find("Keshishyan"));
    EXPECT_FALSE(bst.find("Non"));
}

TEST(AVLTreeTest, InsertFind) {
    AVLTree avl;
    avl.insert("MyName");
    avl.insert("randName");
    avl.insert("Vardan");
    avl.insert("Keshishyan");
    EXPECT_TRUE(avl.find("MyName"));
    EXPECT_TRUE(avl.find("randName"));
    EXPECT_TRUE(avl.find("Vardan"));
    EXPECT_TRUE(avl.find("Keshishyan"));
    EXPECT_FALSE(avl.find("Non"));
}

TEST(BSTreeTest, Remove) {
    BSTree bst;
    bst.insert("MyName");
    bst.insert("randName");
    bst.insert("Vardan");
    bst.insert("Keshishyan");
    bst.remove("MyName");
    bst.remove("randName");
    EXPECT_FALSE(bst.find("MyName"));
    EXPECT_FALSE(bst.find("randName"));
    EXPECT_TRUE(bst.find("Vardan"));
    EXPECT_TRUE(bst.find("Keshishyan"));
}

TEST(AVLTreeTest, Remove) {
    AVLTree avl;
    avl.insert("MyName");
    avl.insert("randName");
    avl.insert("Vardan");
    avl.insert("Keshishyan");
    avl.remove("MyName");
    avl.remove("randName");
    EXPECT_FALSE(avl.find("MyName"));
    EXPECT_FALSE(avl.find("randName"));
    EXPECT_TRUE(avl.find("Vardan"));
    EXPECT_TRUE(avl.find("Keshishyan"));
}

TEST(TreeHeightTest, AVLANDBST) {
    BSTree bst;
    AVLTree avl;
    for (std::string name : {"MyName", "randName", "Vardan", "Keshishyan"}) { bst.insert(name); avl.insert(name); }
  EXPECT_GE(bst.get_height(), avl.get_height());
}

int main(int argc, char **argv) {

    ::testing::InitGoogleTest(&argc, argv);
    return RUN_ALL_TESTS();
}
